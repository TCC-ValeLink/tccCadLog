<?php include("blades/top.php") ?>
<?php include("blades/srcEmp.php") ?>
<div class="body-home">
    <div class="topemp">
        <img src="../img/fundoemp.png" class="capaemp">
        <img src="../img/imageemp.png" class="perfilemp">
        <p class="nomeemp">Nome da Empresa</p>
        <div class="funcaoicon"><i class="bi bi-code-slash"></i></div>
        <p class="funcaoemp">Tipo de Empresa</p>

        <div class="editemp"><i class="bi bi-pencil-square"></i></div>
        <p class="editemptxt">Uma breve descrição sobre a empresa</p>
    </div>
    <?php include("../controller/visual-post.php") ?>
</div>
<?php include("blades/menuEmp.php") ?>
<?php include("blades/footercomp.php") ?>