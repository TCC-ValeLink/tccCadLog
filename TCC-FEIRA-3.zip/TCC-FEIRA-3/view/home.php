<?php Include("blades/top.php")?>
<?php Include("blades/src.php")?>
    <div class="body-home">
        <div class="a">
    <?php Include("../controller/visual-post.php")?>
    </div>
    </div>

<?php Include("blades/followemp.php")?>
<?php Include("blades/menu.php")?>
<?php Include("blades/footercomp.php")?>