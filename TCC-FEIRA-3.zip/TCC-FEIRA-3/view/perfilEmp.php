<?php Include("blades/top.php")?>
<?php Include("blades/srcEmp.php")?>
    <div class="body-home">
        <div class="topuser">
            <img src="../img/fundoemp.png" class="capauser">
            <img src="../img/imageemp.png" class="perfilemp">
            <p class="nomeuser">Nome da Empresa</p>
            <div class="funcaoicon"><i class="bi bi-code-slash"></i></div>
            <p class="funcaouser">Tipo de Empresa</p>

            <div class="edituser"><i class="bi bi-pencil-square"></i></div>
            <p class="editusertxt">Uma breve descrição sobre a empresa</p>
        </div>
    </div>
<?php Include("blades/followemp.php")?>
<?php Include("blades/menu.php")?>
<?php Include("blades/footercomp.php")?>