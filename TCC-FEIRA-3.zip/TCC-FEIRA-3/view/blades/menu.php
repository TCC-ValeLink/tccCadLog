<?php Include("top.php")?>

<nav class="menu_ltl">
    <img src="../img/logo.png" style="width:6.4rem; margin-top:2rem; margin-left:1rem;">
        <div class="abre-fecha">
            <i class="bi bi-list" id="btn-exp"></i>
        </div>
        <ul>
            <li class="item-menu ativo">
                <a href="perfil.php">
                <spam class="img-menu"><i class="bi bi-person"></i></spam>
                <spam class="txt-spam">Perfil</spam>
                </a>
            </li>
            
            <li class="item-menu">
                <a href="home.php">
                <spam class="img-menu"><i class="bi bi-buildings"></i></spam>
                <spam class="txt-spam">Home</spam>
                </a>


            </li>
            
            <li class="item-menu">
                <a href="./mapa.php">
                    <spam class="img-menu"><i class="bi bi-geo-alt"></i></spam>
                    <spam class="txt-spam">Mapa</spam>
                </a>
                
            </li>
            
            <li class="item-menu">
                <a href="./vagas.php">
                <spam class="img-menu"><i class="bi bi-briefcase-fill"></i></spam>
                <spam class="txt-spam">Vagas</spam>
                </a>
                

            </li>

            <li class="item-menu">
                <a href="feedback.php">
                <spam class="img-menu"><i class="bi bi-chat-right-dots-fill"></i></spam>
                <spam class="txt-spam">Feedback</spam>
                </a>
                
            </li>
        </ul>
</nav>
<script src="../menu.js"></script>
<?php Include("footercomp.php")?>