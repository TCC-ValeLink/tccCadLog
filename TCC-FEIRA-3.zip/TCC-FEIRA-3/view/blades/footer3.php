<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"              crossorigin="anonymous"></script>
<div class="header3">    
    <div>
        <svg class="waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
        viewBox="0 24 150 28" preserveAspectRatio="none" shape-rendering="auto">
        <defs>
        <path id="gentle-wave" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z" />
        </defs>
        <g class="parallax">
        <use xlink:href="#gentle-wave" x="48" y="0" fill="rgba(0, 117, 92,0.9)" />
        <use xlink:href="#gentle-wave" x="48" y="3" fill="rgba(1, 229, 129  ,0.7)" />
        <use xlink:href="#gentle-wave" x="48" y="5" fill="rgba(0, 193, 108, 0.5)" />
        <use xlink:href="#gentle-wave" x="48" y="7" fill="rgba(158, 255, 48,0.3)" />
        </g>
        </svg>  
    </div>
</div>    
</body>
</html>