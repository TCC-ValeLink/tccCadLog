# tccCadLog
Pasta dedicada a consertar o processamento e a inserção de dados no banco de dados
