<?php Include("top.php")?>

<div class="fllw">
    <div class="compfllw">
        <a href="perfilemp.php">
            <img src="../img/imageemp.png" class="img-emp2">
            <div id="follow-line"></div>
            <p class="tipo-emp">Area Atuante</p>
            <p class="nome-emp">Nome da Empresa</p>
            <div id="follow-line-horizon"></div>
        </a>
    </div>
    <div class="compfllw">
        <a href="perfilemp.php">
            <img src="../img/imageemp.png" class="img-emp2">
            <div id="follow-line"></div>
            <p class="tipo-emp">Area Atuante</p>
            <p class="nome-emp">Nome da Empresa</p>
            <div id="follow-line-horizon"></div>
        </a>
    </div>
    <div class="compfllw">
        <a href="perfilemp.php">
            <img src="../img/imageemp.png" class="img-emp2">
            <div id="follow-line"></div>
            <p class="tipo-emp">Area Atuante</p>
            <p class="nome-emp">Nome da Empresa</p>
            <div id="follow-line-horizon"></div>
        </a>
    </div>
    <div class="compfllw">
        <a href="perfilemp.php">
            <img src="../img/imageemp.png" class="img-emp2">
            <div id="follow-line"></div>
            <p class="tipo-emp">Area Atuante</p>
            <p class="nome-emp">Nome da Empresa</p>
            <div id="follow-line-horizon"></div>
        </a>
    </div>
    <div class="compfllw">
        <a href="perfilemp.php">
            <img src="../img/imageemp.png" class="img-emp2">
            <div id="follow-line"></div>
            <p class="tipo-emp">Area Atuante</p>
            <p class="nome-emp">Nome da Empresa</p>
            <div id="follow-line-horizon"></div>
        </a>
    </div>
    <div class="compfllw">
        <a href="perfilemp.php">
            <img src="../img/imageemp.png" class="img-emp2">
            <div id="follow-line"></div>
            <p class="tipo-emp">Area Atuante</p>
            <p class="nome-emp">Nome da Empresa</p> 
            <div id="follow-line-horizon"></div>
        </a>
    </div>
</div>

<?php Include("footercomp.php")?>