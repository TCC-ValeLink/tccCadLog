<?php Include("top.php")?>

<nav class="menu_ltl">
    <img src="../img/logo.png" style="width:6.4rem; margin-top:2rem; margin-left:1rem;">
        <div class="abre-fecha">
            <i class="bi bi-list" id="btn-exp"></i>
        </div>
        <ul>
            <li class="item-menu ativo">
                <a href="perfilPrivEmp.php">
                <spam class="img-menu"><i class="bi bi-person"></i></spam>
                <spam class="txt-spam">Perfil</spam>
                </a>
            </li>
            
            <li class="item-menu">
                <a href="#">
                <spam class="img-menu"><i class="bi bi-briefcase-fill"></i></spam>
                <spam class="txt-spam">Curriculos</spam>
                </a>


            </li>
            
            <li class="item-menu">
                <a href="./post.php">
                <spam class="img-menu"><i class="bi bi-plus-circle-fill"></i></spam>
                <spam class="txt-spam">Posts</spam>
                </a>
                

            </li>
        </ul>
</nav>
<script src="../menu.js"></script>
<?php Include("footercomp.php")?>