s<?php Include("top.php")?>
    <div id="notid">
        <div class="topnot">
            <p class="pnot">Notificações</p>
            <img src="../img/not_icon.png" class="icon_not">
        </div>

        <button class="btn_mrr">Marcar como lido</button>
        <button class="btn_lim">Limpar tudo</button>

        <div class="card1">
            <div class="icon">
                <img src="../img/icon_not.png" alt="icone">
            </div>
            <div class="content">
                <h2>Fatec</h2>
                <h3>2hrs atrás</h3>
                <p>Você entrou para a lista de espera</p>
            </div>
        </div>

        <div class="card1">
            <div class="icon">
                <img src="../img/icon_not.png" alt="icone">
            </div>
            <div class="content">
                <h2>Fatec</h2>
                <h3>2hrs atrás</h3>
                <p>Você entrou para a lista de espera</p>
            </div>
        </div>

        <div class="card1">
            <div class="icon">
                <img src="../img/icon_not.png" alt="icone">
            </div>
            <div class="content">
                <h2>Fatec</h2>
                <h3>2hrs atrás</h3>
                <p>Você entrou para a lista de espera</p>
            </div>
        </div>
    </div>
<?php Include("footercomp.php")?>