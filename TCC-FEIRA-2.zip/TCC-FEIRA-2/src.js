var btnExp = document.querySelector('#btn-config')
var menuSide = document.querySelector('#toma-toma')

btnExp.addEventListener('click', function()
{
    menuSide.classList.toggle('expandir')
})
